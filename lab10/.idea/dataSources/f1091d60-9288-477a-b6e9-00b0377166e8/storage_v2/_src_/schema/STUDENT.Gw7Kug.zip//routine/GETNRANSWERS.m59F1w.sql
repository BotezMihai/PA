create function getNrAnswers(p_id INTREBARI.id%type) return int as
v_count int;
begin
  SELECT count(*) into v_count from RASPUNSURI where id_intrebare=p_id;
  return v_count;
end;
/

