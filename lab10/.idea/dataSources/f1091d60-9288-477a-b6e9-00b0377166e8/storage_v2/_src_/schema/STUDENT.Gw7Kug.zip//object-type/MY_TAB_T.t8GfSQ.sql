create TYPE my_tab_t AS TABLE OF number;

alter table PROFESORI add id_cursuri my_tab_t
nested table id_cursuri store as newTable;
/

