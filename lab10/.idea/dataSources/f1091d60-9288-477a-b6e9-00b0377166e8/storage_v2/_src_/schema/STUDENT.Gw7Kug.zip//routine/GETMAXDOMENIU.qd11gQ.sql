create function getMaxDomeniu return int as
  v_count int;
  begin
    select max(id) into v_count from DOMENII;
    return v_count;
  end;
/

