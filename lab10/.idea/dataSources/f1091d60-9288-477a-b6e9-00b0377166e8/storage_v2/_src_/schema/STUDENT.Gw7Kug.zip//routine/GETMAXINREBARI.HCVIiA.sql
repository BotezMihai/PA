create function getMaxInrebari return int as
  v_count int;
  begin
    select max(id) into v_count from ISTORICURI;
    return v_count;
  end;
/

