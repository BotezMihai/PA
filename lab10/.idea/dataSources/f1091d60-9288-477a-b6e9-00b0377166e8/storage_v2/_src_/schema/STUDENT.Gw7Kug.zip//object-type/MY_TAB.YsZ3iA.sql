create TYPE my_tab AS TABLE OF number;
alter table PROFESORI add id_cursuri my_tab nested table id_cursuri store as newTableID;
/

