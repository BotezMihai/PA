create PROCEDURE my_proc (id_student number) AS
    maj_bursa number := 2999;
    v_exista number :=0;
    bursa_noua number(6, 2) := 0;
    too_big_bursa EXCEPTION;
    no_data_found EXCEPTION;
    PRAGMA EXCEPTION_INIT(too_big_bursa, -20001);
    PRAGMA EXCEPTION_INIT(no_data_found, -20002);
    bursa_initiala number := 0;
BEGIN
        select studenti.bursa into bursa_initiala from studenti where studenti.id = id_student;

        select count(*) into v_exista from studenti where studenti.id=id_student;   
            if v_exista=0 then
            raise no_data_found;
            end if;
            bursa_noua := bursa_initiala + maj_bursa;

            if bursa_noua > 3000 then
                bursa_noua := 3000;
            end if;

            update studenti
                set bursa = bursa_noua
                where studenti.id = id_student;         

            if bursa_noua >= 3000 then
                raise too_big_bursa;
            end if;

            exception 
                when no_data_found then
               DBMS_OUTPUT.PUT_LINE(id_student || ' nu exista.');
END;
/

