create TYPE ListaCursuri AS TABLE OF VARCHAR2(30)
/

